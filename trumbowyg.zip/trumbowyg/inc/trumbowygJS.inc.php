<script>window.jQuery || document.write('<script src="vendor/jquery-3.2.1.min.js"><\/script>')</script>
<!-- Import prismjs (for highlight) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.13.0/prism.min.js"></script>
<!-- Import Resizimg -->
<script src="trumbowyg/dist/plugins/resizimg/jquery-resizable.min.js"></script>
<!-- Import Trumbowyg -->
<script src="trumbowyg/dist/trumbowyg.min.js"></script>
<!-- Plugins -->
<script src="trumbowyg/dist/plugins/colors/trumbowyg.colors.min.js"></script>
<script src="trumbowyg/dist/plugins/highlight/trumbowyg.highlight.js"></script>
<script src="trumbowyg/dist/plugins/history/trumbowyg.history.min.js"></script>
<script src="trumbowyg/dist/plugins/preformatted/trumbowyg.preformatted.min.js"></script>
<script src="trumbowyg/dist/plugins/resizimg/trumbowyg.resizimg.js"></script>
<!-- Start Trumbowyg -->
<script>
$('#TrumbowygEditor').trumbowyg({
    btns: [
        ['viewHTML'],
        ['historyUndo', 'historyRedo'],
        ['formatting'],
        ['strong', 'em', 'del', 'underline'],
        ['link'],
        ['insertImage'],
        ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull'],
        ['unorderedList', 'orderedList'],
        ['foreColor', 'backColor'],
        ['horizontalRule'],
        ['highlight', 'preformatted'],
        ['fullscreen']
    ]
});
</script>
