<link rel="stylesheet" href="trumbowyg/dist/ui/trumbowyg.min.css">
<!-- Plugins -->
<link rel="stylesheet" href="trumbowyg/dist/plugins/colors/ui/trumbowyg.colors.css">
<link rel="stylesheet" href="trumbowyg/dist/plugins/highlight/ui/trumbowyg.highlight.css">
<link rel="stylesheet" href="trumbowyg/dist/plugins/history/ui/trumbowyg.history.css">
<!-- Import prismjs stylesheet (for highlight) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.13.0/themes/prism.css">
